import sys
import re
import hashlib
import threading
import requests
import time
from urllib.parse import urljoin
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton,
    QTextEdit, QLabel, QLineEdit, QHBoxLayout, QMessageBox, QSpinBox, QProgressBar
)
from PyQt5.QtCore import Qt, QTimer
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from scapy.all import sniff
from scapy.layers.http import HTTPRequest

class CSRFScanner(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Công cụ quét lỗ hổng CSRF")
        self.setGeometry(100, 100, 900, 600)

        self.url_input = QTextEdit()
        self.url_input.setPlaceholderText("Nhập một hoặc nhiều URL (mỗi dòng một URL)")
        self.scan_button = QPushButton("Bắt đầu quét")
        self.output = QTextEdit()
        self.output.setReadOnly(True)
        self.progress_bar = QProgressBar()

        self.thread_label = QLabel("Số luồng:")
        self.thread_spin = QSpinBox()
        self.thread_spin.setRange(1, 20)
        self.thread_spin.setValue(3)

        top_layout = QHBoxLayout()
        top_layout.addWidget(self.thread_label)
        top_layout.addWidget(self.thread_spin)

        layout = QVBoxLayout()
        layout.addLayout(top_layout)
        layout.addWidget(QLabel("Danh sách URL cần quét:"))
        layout.addWidget(self.url_input)
        layout.addWidget(self.scan_button)
        layout.addWidget(self.progress_bar)
        layout.addWidget(QLabel("Kết quả quét:"))
        layout.addWidget(self.output)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

        self.scan_button.clicked.connect(self.start_multithread_scan)

    def log(self, msg):
        self.output.append(msg)

    def extract_forms(self, driver):
        forms = driver.find_elements(By.TAG_NAME, "form")
        return forms  # Lấy tất cả form bất kể phương thức

    def has_csrf_token(self, form):
        inputs = form.find_elements(By.TAG_NAME, "input")
        for inp in inputs:
            name = inp.get_attribute("name") or ""
            if "csrf" in name.lower() or "token" in name.lower():
                return True
        return False

    def submit_form_without_token(self, form, url):
        try:
            inputs = form.find_elements(By.TAG_NAME, "input")
            data = {}
            raw_headers = {
                "User-Agent": "Mozilla/5.0",
            }
            for inp in inputs:
                name = inp.get_attribute("name")
                value = inp.get_attribute("value")
                if name and not ("csrf" in name.lower() or "token" in name.lower()):
                    data[name] = value or "test"

            action = form.get_attribute("action") or url
            full_url = urljoin(url, action)
            method = (form.get_attribute("method") or "GET").upper()

            self.log(f"\n🚨 Gửi lại form KHÔNG có token tới: {full_url}")
            self.log("📤 Dữ liệu đã gửi:")
            for k, v in data.items():
                self.log(f"   └─ {k} = {v}")

            if method == "GET":
                # Gửi yêu cầu GET
                query_string = "&".join([f"{k}={v}" for k, v in data.items()])
                raw_request = (
                    f"GET {full_url}?{query_string} HTTP/1.1\n"
                    + "\n".join([f"{k}: {v}" for k, v in raw_headers.items()])
                    + "\n\n"
                )
                self.log(f"\n📄 Yêu cầu HTTP thô (raw request):\n{raw_request}")
                resp = requests.get(full_url, params=data, headers=raw_headers)
            else:
                # Gửi yêu cầu POST
                raw_headers["Content-Type"] = "application/x-www-form-urlencoded"
                raw_request = (
                    f"POST {full_url} HTTP/1.1\n"
                    + "\n".join([f"{k}: {v}" for k, v in raw_headers.items()])
                    + "\n\n"
                    + "&".join([f"{k}={v}" for k, v in data.items()])
                )
                self.log(f"\n📄 Yêu cầu HTTP thô (raw request):\n{raw_request}")
                resp = requests.post(full_url, data=data, headers=raw_headers)

            if resp.status_code in [200, 302]:
                self.log("⚠️ Máy chủ phản hồi OK (200/302) => Có thể tồn tại lỗ hổng CSRF!")
            else:
                self.log("✅ Máy chủ từ chối => Có kiểm tra token CSRF.")
        except Exception as e:
            self.log(f"   [Lỗi gửi form] {e}")

    def detect_unsafe_endpoints(self, html):
        patterns = [
            r"<form[^>]+method=[\"']?(post|get)[\"']?[^>]*>",
            r"fetch\([^,]+,\s*\{[^}]+method:\s*['\"](post|get)['\"]",
            r"\$.(post|get)\("
        ]
        findings = []
        for pattern in patterns:
            matches = re.findall(pattern, html, flags=re.IGNORECASE)
            findings.extend(matches)
        return findings

    def check_origin_referer(self, packet):
        if packet.haslayer(HTTPRequest):
            method = packet[HTTPRequest].Method.decode()
            if method in ("POST", "GET"):
                headers = str(packet[HTTPRequest].Headers)
                if "Origin" not in headers and "Referer" not in headers:
                    self.log(f"⚠️ Gói {method} phát hiện không có Origin/Referer header!")

    def analyze_token_entropy(self, tokens):
        if not tokens:
            return 0
        return len(set(tokens)) / len(tokens)

    def scan_url(self, url, index, total):
        self.log(f"\n🔍 === Bắt đầu quét URL: {url} ===")
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        driver = webdriver.Chrome(options=chrome_options)

        try:
            driver.get(url)
            forms = self.extract_forms(driver)
            csrf_tokens = []

            for i, form in enumerate(forms):
                action = form.get_attribute("action")
                method = (form.get_attribute("method") or "GET").upper()
                inputs = form.find_elements(By.TAG_NAME, "input")

                self.log(f"\n📄 [Form #{i+1}] Action: {action or '[Không có]'} | Method: {method}")
                if method == "GET":
                    self.log("⚠️ Cảnh báo: Form GET có thể không an toàn nếu thay đổi trạng thái máy chủ!")
                self.log("📝 Các trường input:")
                for inp in inputs:
                    name = inp.get_attribute("name") or "[Không có tên]"
                    val = inp.get_attribute("value") or ""
                    self.log(f"   └─ {name} = {val}")

                if self.has_csrf_token(form):
                    token_input = [inp for inp in inputs if 'csrf' in (inp.get_attribute("name") or '').lower()]
                    for token in token_input:
                        val = token.get_attribute("value")
                        csrf_tokens.append(val)
                    self.log("✅ Phát hiện token CSRF trong form.")
                else:
                    self.log("❌ Không phát hiện token CSRF. Đang thử gửi lại form không có token...")
                    self.submit_form_without_token(form, url)

            entropy = self.analyze_token_entropy(csrf_tokens)
            self.log(f"\n🔐 Độ ngẫu nhiên của token: {entropy:.2f}")

            html = driver.page_source
            findings = self.detect_unsafe_endpoints(html)
            if findings:
                self.log("\n🔥 Phát hiện endpoint nguy hiểm trong mã HTML:")
                for f in findings:
                    self.log(f"   └─ {f}")

            self.log("\n🕵️ Bắt gói kiểm tra header...")
            sniff(filter="tcp port 80", prn=self.check_origin_referer, count=5, timeout=10)

        except Exception as e:
            self.log(f"[Lỗi] {e}")
        finally:
            driver.quit()
            self.log(f"\n✅ ✅ ✅ Hoàn tất quét URL: {url}")
            self.log("=" * 60)
            self.progress_bar.setValue(int((index + 1) * 100 / total))

    def start_multithread_scan(self):
        urls = [url.strip() for url in self.url_input.toPlainText().splitlines() if url.strip()]
        thread_count = self.thread_spin.value()

        if not urls:
            QMessageBox.warning(self, "Thiếu dữ liệu", "Vui lòng nhập ít nhất một URL để quét.")
            return

        self.output.clear()
        self.progress_bar.setValue(0)
        self.log(f"[*] Bắt đầu quét {len(urls)} URL với {thread_count} luồng...")

        self.completed_count = 0

        def worker(urls_subset, thread_id):
            for u in urls_subset:
                self.scan_url(u, self.completed_count, len(urls))
                self.completed_count += 1

        chunks = [urls[i::thread_count] for i in range(thread_count)]
        threads = [threading.Thread(target=worker, args=(chunk, i)) for i, chunk in enumerate(chunks)]

        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.progress_bar.setValue(100)
        self.log("\n🔥 Tất cả URL đã được quét.")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = CSRFScanner()
    window.show()
    sys.exit(app.exec_())